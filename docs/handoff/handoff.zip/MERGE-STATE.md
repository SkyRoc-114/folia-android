# MERGE-STATE.md — folia-android 合并状态（会话间接力文档）

> **2026-11-06 起分支重构：main = 唯一长期分支（本文件随 main 提交，clone 即得）；agent-cowork = 协作分支**；
> android-0.7.22 分支已退役删除（tag 独立保留）；未推送的本地提交会在沙箱重置后丢失 —— 每批做完立即 push。

## 仓库关系

- `origin` = https://github.com/SkyRoc-114/folia-android （Android 移植 fork，main = 唯一长期分支，agent-cowork = 协作工作分支）
- `upstream` = https://github.com/chthollyphile/folia-major （上游桌面版）
- `whycfawa` = **Android 上游**（`https://github.com/whycfawa/folia-android`，2026-11-03 用户确权）：分支 `android-0.7.22`（本 fork 直接父本，2026-11-05 tip=5193fd0d，55af65d 后新增 11 提交：Android 模组系统 8 笔 + QQ 登录修复 + 启动图 WebP 瘦身，待 .304 迁移）、`android-0.7.21`、`main`（0.7.20-android.194）；书脊/phone-fit 行为以其为准（对齐即"看上游"）。旧记录的 `whycfawa/folia` 已 404，勿再引用
- 凭证：`/home/z/my-project/.gh-credentials` 与 `~/.git-credentials`（credential.helper=store）——**用户拍板复用已持久化的 PAT（前缀已脱敏为 ghp_[REDACTED]，2026-11-05 复核现行为 fine-grained github_pat_ 类），沙箱重置后从 `git clone https://@github.com/...` 自动走 credential.helper 恢复**
- ⚠️ PAT 绝不能写进仓库任何被跟踪的文件

## 当前进度（2026-11-06 +08 更新）

- **.305 桌面上游 v0.7.26 同步批次（2026-11-06，用户确认「现在启动 .305」+ electron 专属「共享层收、专属跳」）**
  - **范围**：folia-major a10a0983..cc6226e4（v0.7.26 tag=main tip）21 提交/15 非合并 → **收 8 笔**（6 全收 + 2 裁剪）：9a614089 补页不再被过期曲目数截断、2881d45b bravais 刷新歌单挪到曲目数、fc135259 账号页「同步数据」按钮（LoginScreen 解构与 .294 onEscape 合流，LoginHost 接线 onSync/syncingProviderId）、4b1428ef 逐行歌词按字估算扫字（新增 estimatedLineTiming.ts，莫奈长行折行不再整块点亮）、88eeb9bf machi 固定节拍霓虹随拍/大屏闪拍、90363e44 machi「模拟节拍」开关、09002f6a v0.7.26 版本面（Fawkes 弹窗+四语释放说明；package/lock/docker VERSION/realeco-release 取 OURS）、c1a5065d apple-music Windows 转正 **src 共享层**（transport 门控放开+Windows 待定文案移除+vite-env 摘实验旗标）
  - **跳过（electron/Windows 专属或零安卓语义）**：29e3ae05/611d3811 apple-music Windows 宿主（fork 保留 electron 实验门控，注册表计数随 src 摘除 5→4 用 `platformNameCount.ts --lower` 降数，omniArchitecture 守卫复绿）、6731e146 hifi mpv 0.42.0、9033f4a6/d206c7c6 netease worker IPv4/IPv6（fork 无 electron/netease/）、c1b7907b lazyJsdom、b0d11ad5 codemap
  - **验证**：tsc ×2 EXIT=0；全量三片 4848+4803+4418=14069 + ytm 358 = **14427 过** + 1 存量败（ytmProvider sign-in 基线，勿修）+ 4 skip，**较 .304 净增 22 例零新败**；vite build 0 错；16 屏重渲整组替换（14 号登录窗=空态兜底实拍与 .304 同基线，README 基线更新 .305）
  - **发布**：dac83ab0 + tag v0.7.22-android.305，push main+tag 一次过
  - **同轮情报（whycfawa 4 个未合并 PR 评估，只读 API 侦察，细节入 PROGRESS pending `whycfawa-pr5-android-perf`）**：#5 perf(android)（base=android-0.7.22）**改造后收**——封面 LRU/墙滚动动态降级/未节流 rAF 滑行/lattice 不补间尺寸/hanabi 模糊降档，fork 实锤同 bug（无界封面缓存、限帧闸接管惯性 rAF）；dpr 钳制需折进 lyricRenderQuality（max=安卓 2）勿移植 renderPixelRatio.ts；#6 纯集成线（736 提交）跳过；#10 被 #11 完全包含；#11 TV/投影仪（+11.4K 行独立 tv.html 入口）**待用户决策**（全收 8-16h 独立分支 或 只摘 gradle JDK 路径修复/useElementSize/back 补发 Escape/isTvSurface 4 小件 1-2h）
  - **环境备注**：渲染脚本必须跑在 /home/z/my-project/scripts/ 层（repo 内 scripts/ 会被 repo 本地 node_modules 的 playwright 挟持要 1243，npm-global 1.57 对应缓存 1200）；vite preview 与渲染必须同一条 Bash 调用内完成（后台进程跨调用被回收）

- **⚠️ 分支策略重构（2026-11-06 用户指令「所有提交提交到 main（保持最新），删除其他分支。新增分支用于写 agent co work」）**：
  - **main = 唯一长期分支**（default branch 已是 main，已 force 对齐原 android-0.7.22 tip）；**agent-cowork = 协作工作分支**（进行中工作先落它，验证后合回 main）；**android-0.7.22 已删**（远端+本地）；tag 独立保留不受影响
  - workflow 全部已挂 main：android-pre-release 走 tag 触发（分支无关）；codemap-sync/pr-unit-tests 挂 main push——**codemap 在 main 自动提交已实证**（run #3 success，ceeccfdb）
  - 交接文档 `docs/handoff/HANDOFF.md` + handoff.zip（download/ 与仓库双份）；协作协议见 HANDOFF 第 2 节
- **.304 安卓上游模组系统迁移批次（2026-11-06，pending upstream-android-mods 兑现）**
  - **范围**：whycfawa android-0.7.22 分支 55af65d..5193fd0d 共 11 提交（上游版本号已是 0.7.25-android.299+ 体系）：启动图 WebP（26 张 PNG 21.4MB→0.32MB）、QQ 禁止降级原生快速登录、Android 客户端模组系统全家桶（FoliaModsPlugin 364 行 + FoliaModsServer 166 行原生宿主：zip 导入/删除/启用/本地 HTTP 文件服务；复用桌面 ModManager；net.fetch 走 FoliaNative.httpRequest 绕 WebView CORS；storage/secrets 按模组隔离；分辨率保护开关→三挡：轻度压画布 75%/均衡关阴影/强力再关模糊混合）
  - **fork 侧适配**：①MainActivity 只注册 FoliaModsPlugin（上游还注册 qishui/analysis 两插件，fork 走大一统 FoliaNativePlugin，那两个类不存在）；②**androidModsBridge 拔掉 app store 依赖**——上游 b3b4c846 在桥层重复实现模组总开关门禁（useDesktopSettingsStore.getState()），使 folium services 闭包（services→ipc→androidModsBridge）可达 3 个 app store，违反桌面 Folium 1.8 模组窗口包隔离（foliumServicesBoundary 守卫，上游没跑单测所以没发现）；ModManager.tsx:223 UI 层（闭包外）已有同款门禁，桥层只守平台，语义不丢；③platformNamePlaces 注册表随 QQ 迁移更新（cookies 52/folia 149/qq.js 664，omniArchitecture 守卫）
  - **工具**：scripts/pick-304.sh 轻量迁移驱动（version 三件套 auto-ours + 冲突停 11 笔只停 2 次：ANDROID_PORT.md 纯追加型 sed 删标记、MainActivity 手工裁决）
  - **验证**：tsc 0 错；全量三片 14047 + ytm 358 = **14405 过** + 1 基线败（ytmProvider sign-in，存量）+ 4 skip，零新增失败（基线数字自 14410 修正为 14405，上轮口径含混）；vite build 0 错；16 屏重渲 + 模组子页 DOM 实证（scripts/verify-mods-304.mjs，Capacitor mock getPlatform=android：设置 12 类目含「模组」/总开关/性能优化开关/开盾后三挡 轻度·均衡·强力 PASS；三挡 IS_ANDROID_WEBVIEW 守卫浏览器默认不显示属设计）
  - **发布**：workflow run #29 success；3 APK 各 **18.9MB（.303 为 37.6MB，WebP 瘦身 50%）**
  - **上游遗留（下批素材）**：55af65d9 模型导入 ZIP 及其前面的 AnalysisModelImporter/FoliaAnalysisModelsPlugin 系列（fork 无此基础，需成系列评估）；桌面 folia-major 仍 v0.7.25 无新 tag

- **.303 上游 folia-major 全量迁移批次（2026-11-04/05，用户指令「查看 folia-major 的功能是否推进（功能上游），更新」）**
  - **范围**：v0.7.25 之上 main（tip a10a0983）非合并提交 172 个，跳过 5 个代码地图 [skip ci]、1 对 logo 加/回退净零、3 个 .292 已迁 → cherry-pick 163 个：速记簿（scratchpad 全家桶）、飞牛 fnmusic 平台、Apple Music 伴随播放器、跨平台混合队列、听歌排行、至上主义搜索重构、播放胶囊命令系、雾笺 融雪/雪窗/水族箱/萤虫、machi 降级修复、RTL 歌词、歌词原名/译名、Stage 外部播放器、全局快捷键范围、每日推荐风格化等
  - **fork 语义保全清单**：.294 死曲即时跳（playSong/skipAfterPlaybackFailure 双路径，loading 提示抑制，上限 20；queueReplaceRaces 倒数窗场景改用 unknown 案）、.301 面板分类徽章删除（上游 panelBox 重构曾使其回流，二次删除）、.302 设置子页板块一览、.300 离线哨兵 × 多类型搜索语义合并（restoreSearch/submitSearch kind 感知）、phoneFit 胶囊固定展开 × 槽位提议并集、phoneFitKind=playlist-selection、types 的 requiresSameOriginAudio/confirmSessionLoss
  - **⚠️ 新工具坑**：①blob:none 部分克隆下 cherry-pick 逐 commit 懒拉 blob 且易 GnuTLS 断——解法：清 remote.partialclonefilter 后带 blob 加深 fetch（refetch 全量会被网断，逐 commit 重试可行）；②**Bash 工具输出层会吞字面 `[m`（当 ANSI 处理）**——排查时 cat -A 也会显示成损坏文本，`grep -c` 才可信（本次「上游坏行」虚惊）；③上游 panelBox 重构后行不再挂 command-palette-match-row testid，渲染脚本改用 `[data-testid=command-palette-body] button`
  - **验证**：tsc EXIT=0（需 --max-old-space-size=3072）；全量 3 分片 14410 过 + 1 基线败（ytmProvider:813→818 挪行）+ 4 skip；vite build EXIT=0；16 屏重渲（13 屏新面板实证：无分类徽章、mono 触发词 chip、「回到首页」在列）
  - **教训**：迁移提交必须每 10 个 push 检查点（本窗开局沙箱回退，首轮 60 提交全灭，推检查点后重来未再丢）
- **.302 设置子页去页签条批次（2026-11-04，用户指令「图11 的 UI 还是修改之前的模板…只有 3 个板块，考虑新设计」）**
  - PageHeader 窄窗下钻页不再渲染锚点页签条，改标题下一行「板块一览」（分组名 · 相连，data-folia-page-header-contents）；宽窗页签不变；渲染集 01-15 重出
  - 验证：tsc 0、settings 216 例全绿、build 0；11 屏实证
- **2026-11-05 巡检机制/仓库治理**：cron 进度变量化（PROGRESS.json+update-progress.py，见 2026-11-04 条）；**远端过期分支清理（用户指令「远端分支混乱，main 为主，删除过期分支」）**：删 meta 孤儿分支（204），剩 main+android-0.7.22；**敏感面审计**：全部 25 refs（2 分支+23 tag）树扫+提交信息扫+workflow 核查——无凭证/密钥文件入库（.env.example 均为模板）；android/app/folia-release.p12+keystore.properties 入库=**文件头注释明示的取舍**（覆盖安装连续性优先，换私有 keystore 需全量卸载重装），非意外泄漏；MERGE-STATE.md 的 PAT 前缀已脱敏为 ghp_[REDACTED]
- **.301 命令面板分类徽章删除批次（2026-11-04，用户指令「是13号图片右侧的徽章」= 命令面板行标题右侧分类小标签）**

- **2026-11-04 巡检机制升级（用户指令「cron 进度为常量，改为变量单独存储按轮次实时更新」）**：cron 载荷【当前进度】常量段退役，唯一变量存储=仓库根 **`PROGRESS.json`**（fork 最新 tag/下一批号/回归基线/渲染集/pending/观察项/上游状态/最近 8 批摘要/last_round 轮次记录），更新器 `scripts/update-progress.py`（set/set-json/round/history/pending-*，scripts/* 同既有脚本 force-add）；**每轮（巡检含）收尾必跑 round + 随批 push**；与远端 tag 冲突时以 ls-remote 为准回写。.301 闭环核验：tag→release（3 APK）→workflow success 全部在线（并行实例完成，本窗仅核验不重做）
- **.301 命令面板分类徽章删除批次（2026-11-04，用户指令「是13号图片右侧的徽章」= 命令面板行标题右侧分类小标签）**
  - **改动**：删除 match 行（CommandPalette.tsx）与「全部命令」行（CommandPaletteAllCommandsRow.tsx）标题右侧的 groupLabel 圆角小标签（搜索/设置/导航/播放等），连带清掉 `groupLabelKey` 常量、match 行 groupLabel 计算与 AllCommandsList→Row 的 props 链路；i18n `commandPalette.group*` 键保留未删（防上游回用，零风险）。队列视图里时长/元数据小 chip 不在本次范围，保留
  - **连带**：render-mobile-ui.mjs 行匹配串去掉徽章拼文（'Lattice 打开导航'→'Lattice 打开'、'打开选项设置'→'打开选项'、'回到主页'→'回到首页'——最后一个本就是旧错串，靠徽章删后暴露）；补交 .300 漏入库的 `docs/ui-preview/16-offline-search.png`；lockfile 根 version 补齐后随本批跳 .301（.300 重蹈 .294 漏改 lock 覆辙）
  - **验证**：tsc EXIT=0；command-palette 定向 28 文件 313 例全绿；vite build EXIT=0；13 屏重渲实证徽章消失（01-14 全套重出，10-settings-landing 恢复 landing 命中）
  - **⚠️ 沙箱 npm 新坑（EALLOWREMOTE，排查久）**：`npm install` 全量失败 `Fetching non-root packages of type "remote" have been disabled`——根因是沙箱环境变量 `NPM_CONFIG_REGISTRY=https://registry.npmmirror.com` 覆盖项目 .npmrc 的 npmjs 源，npm 11.19 新 allowRemote 策略下 lockfile 里的 registry.npmjs.org tarball 与生效 registry 主机不匹配 → reify extract 阶段 `#isRegistryResolvedTarball` 判否 → 一切 registry 包被当 remote 拒装。**解法：`NPM_CONFIG_REGISTRY=https://registry.npmjs.org/ npm install --ignore-scripts --no-audit --no-fund`（对齐 lockfile 主机，策略本身不动）**；排查法：进程内 require 系统 npm + 包一层 pacote `FetcherBase.get` 打 spec/`_isRoot`（scripts/npm-debug-install.cjs 存档）；勿再走 vendor/file: 置换弯路（不影响报错根源）
- **.300 搜索离线判定批次（2026-11-03 上午，用户指令「未连接网络没有判定会直接显示歌曲搜索失败，优化，继续优化GUI并渲染」）**
  - **根因**：断网时在线源搜索仍发起注定失败的请求，WebView 抛含混的 "Failed to fetch" 被笼统显示成「搜索失败，请重试」，无网络状态判定。链路上还有一坑：store 置错后 `onSearchCommitted` → `navigateToSearch` → `pushNavigationState` → `restoreHistoryState` → `restoreSearch` 会无脑清 error，把「未连接网络」洗成「未找到相关结果」
  - **修复（三件）**：①新模块 `src/utils/networkStatus.ts`——`isNetworkOffline()`（navigator.onLine===false 才算离线，无 navigator/SSR 按在线处理防误拦）+ `subscribeNetworkStatus`（online/offline 事件）+ `useNetworkOffline()`（useSyncExternalStore）；②store 离线预检——`submitSearch` 对非 local 源断网直接置 `searchError=SEARCH_OFFLINE_ERROR`（导出哨兵，复用 searchError 管线不加字段）短路返回、`loadMoreSearchResults` 同理；③`restoreSearch` 同词同源**且仍离线**时保留哨兵（回网自动回落缓存/空结果，后退导航旧错误照旧清）；显示层 SearchWorkspace 离线态换 `WifiOff` 图标 + `search.offline` 文案（空态+底部条两处）。locale 双语加 `search.offline`（未连接网络，请检查网络后重试。/ No network connection...）+ sync-vi（vi 英文占位）
  - **验证**：tsc EXIT=0；定向 20 例全绿（store 4 新：离线短路不发起请求/本地源离线可用/loadMore 离线哨兵/哨兵跨 restoreSearch 存活三态；networkStatus 4 新）；全量 3 分片 13757 过 + 1 存量败（ytmProvider:813 基线内）+ 3 skip；vite build EXIT=0；**16 屏渲染集重出**（新增 `16-offline-search.png`：context.setOffline(true) 提交搜索 → WifiOff+「未连接网络」实截，脚本 `scripts/render-offline-search.mjs` 入库含三断言：offlineText/wifiOff/无 failedText 残留）；01-15 重出人工查验（书脊横条/设置落地页/面板全 zh 均确认）
  - **⚠️ 会话事故与排查教训（第 N+1 次沙箱回退，形态更新）**：本批渲染时发现「命令面板 rows=0、.297 修复消失」——排查后确认**仓库在会话中途被回退到 .287**（HEAD=1f696ba3，git status 假象同步），导致：新构建 dist=.287+我的修复、01-14 首轮渲染全作废、且 `rg -rn`（-r 是替换显示旗标！）与 GitHub raw 比对造成的「.297 修复未提交」误判——**实际 .297 修复（删 chip/删 placeholder 覆写/行 testid）全部在 .299 tag 里**（GitHub raw 三方核对：font-mono=0、match-row testid=1）。恢复法升级：回退基点与目标只差 12 提交时，**`git fetch origin android-0.7.22 --depth=30` 增量 + `git reset --hard origin/android-0.7.22` 可行**（首次跑通，不再必须 depth-1 全量克隆 cp -a）；回退前先 `git diff HEAD > patch` + untracked 文件 cp 备份，reset 后 `git apply` 套回（本次 5 文件 310 行 patch 干净套上）
  - 教训：每轮动手前先 `git log --oneline -1` 核 HEAD（本轮 .299→.287 回退发生在渲染与 git log 之间，靠「.297 修复不在源码」的矛盾倒查发现）；rg 的 `-r` 是 replace 显示旗标，计数一律用 `grep -c` 复核
- **.299 书脊横排回归 + 设置传统化 + 平板双栏批次（2026-11-03 上午，用户指令「就是万象这个布局，书脊在android上应该是横着的，看上游(folia android)，继续安卓化，设置界面跟随传统音乐软件，平板端分成2部分，记得删除截图」）**
  - **关键情报修正：Android 上游确权 = `whycfawa/folia-android`**（用户给出 URL；此前 MERGE-STATE 记的 whycfawa/folia 404 已过时）——分支 `android-0.7.22`（tip 55af65d）是本 fork 直接父本，`main` 在 0.7.20-android.194；另有 `android-0.7.21`。另调研 `CYJ316457/folia-android` = Kotlin+Compose 原生重写垂直切片（非 WebView），其顶部 TabRow+列表+底部浮条 = 传统安卓音乐 UI 参照；技能 `superpowers-cn` 已按用户指令安装（clawhub → /home/z/my-project/skills/superpowers-cn，方法论框架：澄清→设计→执行→审核）
  - **①书脊横排回归上游（撤销 .296 触屏竖排兜底 + .295 seam 44px 触点规则）**：上游 `libraryWallSeamDirection.ts` 仅有 `resolveLibraryWallSeamHorizontal`（auto+竖屏→横条）、BravaisStage 直接调用、phone-fit CSS 零 seam 规则（541 行内 bravais-seam 零命中）——本 fork 的 44px seam 规则与竖排兜底都是自增偏差。删除：`resolveLibraryWallSeamHorizontalForTouch` + `LIBRARY_WALL_SEAM_ROW_NARROW_QUERY` + BravaisStage 两媒体查询 + androidPhoneFit.css 末尾 seam 段（44px/ home-tab/工具格居中共 32 行）；测试文件整文件恢复上游版（-20 行）。探针复测 360×640：全按钮 34px 上游原生、页签文字偏移 0.00、行无溢出（页签导航段 60px 横滑触达五页签=上游退让链 short+overflowing 终态，与上游 Android 真机一致）
  - **②设置传统移动端化（跟随传统音乐软件：根列表→子页返回，M3 官方「设置=list-detail 典型场景」）**：窄窗（<768px）抽屉式——`settingsLandingOpen` 状态（深链子视图/锚点/help 直达子页，裸开=根列表）；SettingsSideList 新增 `stacked` 变体（分组竖排列表任意宽度生效，data-folia-settings-landing 钩子，children 支持搜索结果替换列表）；PageHeader 新增 `onBack`/`backLabel`（← 返回箭头）+ `data-folia-page-header-bar` 钩子；phone-fit CSS 全屏 edge-to-edge（padding 0/100dvh/方角/安全区 padding，替换原 6px 内缩浮动卡）+ 落地页行/页头钮 44px 触点。locale 双语加 `options.settingsBack`（返回/Back）+ sync-vi-to-en。渲染实证：10-settings-landing（全屏搜索+分组类目）、11-settings-section（←+外观+锚点页签）
  - **③平板双栏（「分成2部分」，M3 expanded 两栏 canonical）**：缝=墙中间裂开的那道缝，竖缝把墙分成左右两部分。新增 `resolveLibraryWallSeamHorizontalForTablet`（fork 增量，纯函数+单测）：触屏平板（coarse+宽≥720+高≥720，LIBRARY_WALL_SEAM_TABLET_{MIN,TALL}_QUERY 合成）上两种「自动」一律竖缝、两种朝向一致；显式「横向」仍尊重；手机（短边<720）与非触屏走上游语义零变化。探针 `scripts/probe-tablet-seam.mjs`（入库）四断言全过：平板竖 800×1280 竖缝 x=365 w=64 全高 / 横 1280×800 x=577 w=120 / 桌面 800×1280 横条 / 手机 360×640 横条
  - **④验证**：tsc EXIT=0；vitest 全量 3 分片 = 13749 过 + 1 存量败（ytmProvider:813，基线内）+ 3 skip（新增 1 平板用例）；vite build EXIT=0；15 屏渲染集重出（**10-settings-options 改名 10-settings-landing**，旧截图按「删除旧的」指令清除，README 清单+探针实证段同步更新）
  - 教训：上游确权要先 ls-remote 各分支再下结论（404 的 repo 可能改名，且同名 org 下有新 repo）；「上游零 seam 规则」是书脊问题的正解而非继续叠 fork 补丁
- **.298 书脊工具格右偏修复批次（2026-11-03 早晨，用户实测「首页（无界布局）的字体按钮似乎右偏」）**
  - **定位**：非渲染精度（页签竖排文字中心偏移 0.91px 亚像素）——真凶是 .295 触点规则 `min-width:44px !important` 把上游定宽的工具格按钮（书脊 36px/窄缝 40px）真实撑大到 44px，溢出 grid 轨道且 item 默认左对齐 → 搜索/设置/队列拼贴/更多四格右偏（书脊 4px、窄缝 2px/格，列间 8px 设计间隙被吃成 4px）。探针实测：书脊四格 cx=181.92 vs 其余按钮 177.92
  - **修法**：androidPhoneFit.css 末尾追加 phone-fit 作用域规则——`.bravais-seam-tools .bravais-seam-icon:not(.is-wide) { justify-self: center }`（+is-compact is-wide 同样居中；窄缝 is-wide stretch 占满两列保持不居中）。触点 44px 不变、关 phone-fit 上游零变化
  - **验证**：探针复测书脊四格 cx→177.92 同轴、窄缝对齐轨道中心（153.92/201.92）+ 间隙恢复 8px；vite build EXIT=0；15 屏渲染集重出人工查验；vitest unit 不涉（纯 CSS）
  - **持久化新规（用户指令「完成任务都持久化当前仓库状态（删除旧的）」）**：渲染集 15 屏 + README 清单**入库 `docs/ui-preview/`**（沙箱 download/ 每窗口被回退清空，仓库是持久正本；每次重渲染整组替换不留旧版）；新增几何探针 `scripts/probe-spine-geometry.mjs` + `probe-seam-expanded.mjs` 入库（-f，scripts/* 被 .gitignore）
  - **cron 巡检频次改每日一次（用户指令）**：job 重建为每天 09:00 Asia/Shanghai；沙箱快照每窗口回滚到 .287 是常态，每轮先 depth-1 克隆 cp -a 替换恢复
- **多界面渲染集补齐批次（2026-11-03 凌晨，用户遗留任务「多界面全量枚举渲染 16+ 屏」收口，docs 推送无发布）**
  - **沙箱回退恢复新路径（API tarball 法）**：本轮快照回退到 .287（1f696ba3）+ **github.com 主站通道不通**（depth-1 clone 三连败，curl -I github.com 无响应但 api.github.com/registry.npmjs.org 正常）→ `curl -L -H "Authorization: token $PAT" api.github.com/repos/SkyRoc-114/folia-android/tarball/android-0.7.22`（58MB 一次到手，302→codeload 跟随可达）解压替换工作树；随后网络窗口恢复 depth-1 clone 成功，`cp -a /tmp/folia-git/.git <repo>/` + `git reset --hard` 补回 .git。**快照回退波及沙箱外部目录**：download/mobile-ui-preview/ 旧 4 张、scripts/render-mobile-ui.mjs 全丢——渲染脚本从此入库防丢（本批 scripts/render-mobile-ui.mjs + render-extra.mjs + probe-{dom,palette,player}.mjs 五件入库）
  - **渲染集 15 屏重建（download/mobile-ui-preview/，1080×1920、phone-fit 显式开、zh-CN，README.md 有清单）**：01 home 墙 / 02 本地页签 / 03 lattice / 04 player / 05-07,09 面板 4 tab（**未登录下 TabDock 只渲染 cover/controls/queue/account 四个**，local/navi/onlineLyrics 不可用不出现） / 08 均衡器 / 10-11 设置 options+主题 section / 12 搜索激活态 / 13 命令面板 / 14 登录窗 / 15 搜索覆盖层。逐张人工查验通过
  - **.297 双语修复复渲染实证**：13 屏命令面板行=zh 标题+zh 分类 chip（`队列 [播放]` 形态）；12 屏搜索激活 placeholder=zh「在当前来源搜索歌曲」——两处修复在 1080×1920 真机分辨率确认无英文等价物
  - **导航侦察结论（渲染脚本导航手段）**：无 window 调试句柄、hash 只写不读（无直达）→ 三条路：①命令面板命令（⌘ 按钮 → `[role="combobox"]` 输入**英文关键词**（primaryTerm 检索词语义仍在）→ 点 `[data-testid="command-palette-match-row"]`，行含 zh 文本可按文本选行）；②书脊 aria-label——**页签 role=tab 非 button**（`button[aria-label="本地"]` MISS 根因，用 `[aria-label=…]` 或 getByRole('tab')）；③播放页 `[data-testid="panel-toggle"]` → `[data-ponder-panel-tab-button="<id>"]`
  - 首启门控预置五键（渲染/审计必带）：`folia_android_phone_fit='true'`、`playback_entry_view_chosen='true'`、`library_suite_prompt_seen='true'`、`folia_last_seen_ponder_onboarding_version=<pkg version>`、`folia_last_seen_guide_version=<pkg version>`（__APP_VERSION__=package.json version，当前 0.7.22-android.297）
  - 观察项（非阻塞，见渲染集 README）：①面板 × 关闭钮与末 tab「音质」360 宽空态下轻微重叠；②命令面板 placeholder 与 ？ 帮助钮轻微重叠；③空态大量入口不渲染（player-bar/lattice pill/登录后才有 3 tab）——登录+有播放内容后可再补
- **命令面板英文等价冗余清除批次（2026-11-02，用户截图命令面板 zh 界面并指令「这种为什么右边还有英文对应的，这样语言切换为en-us不会重复？去掉（不止一处）」，随 .297 发布）**
  - 根因两处（用户「不止一处」实证为二）：①CommandPalette 匹配行的等宽提示 chip——数据源 searchIndex 的 `primaryTerm`（=英文标题规范化，en 标题恒为触发词），**所有语言都上屏**：en 界面与标题逐字重复（`Queue [queue]`），zh 界面是游离英文等价物（用户截图的 `队列 [queue]`/`搜索歌曲 [search songs]`）；②searchCommands 的 placeholder 覆写 `` `${keywords[0]} ${description}` ``——激活搜索命令后输入框漏英文（keywords[0]='search' + 硬编码英文描述），其余 20+ 命令的 placeholder 全走 i18n 键，唯此一处硬编码
  - 修复：①删 chip（行=本地化标题+本地化分类，布局不动）；②删 placeholder 覆写（回落 renderQueryInput 的 `getCommandDescription` 本地化描述链）。**primaryTerm 字段保留**——语义收窄为「全部命令点选回填 + 激活命令 Backspace 回退」的检索词（commandPaletteVirtualList.spec L102 的 ASCII 回填断言锁定该功能：回填必须能原样搜出命令，本地化标题也能命中但测试语义是「回填词」而非展示文案，不动）；行上加 `data-testid="command-palette-match-row"`，commandPaletteSizing.spec 的「匹配列表已渲染」信号从 `span.font-mono` 换成该 testid（chip 删了信号就没了）
  - 验证：tsc 直跑 EXIT=0；command-palette 单测 **313 例全绿**；vite build OK；agent-browser 实证 zh/en 双语言 `span.font-mono` 计数=0、en 行=`Queue/PLAYBACK` 无重复、搜索激活 placeholder zh=`在当前来源搜索歌曲` en=`Search songs in the current source`（都无英文关键词前缀）
  - 复渲染确认（用户指令「使用技能，复渲染确认」+「删除旧的截图」）：download/mobile-ui-preview/ **旧截图全删重做**，现 4 张 1080×1920 phone-fit 显式开（folia_android_phone_fit='true'）zh-CN：01 home 墙 / 02 palette zh 修复后 / 03 palette en 修复后 / 04 搜索激活态（本地化 placeholder）。多界面全量枚举渲染（16+屏）仍未完——本轮只交付修复确认集
  - ⚠️ 环境坑更新：①blobless clone `git fetch origin`/`git fetch /tmp/folia-fresh` 回填 blob 均超时卡死（150s×2），**depth-1 全量克隆 `cp -a` 整体替换 `<repo>` 的 .git+工作树**最稳（损失历史但 push/tag 正常，快照回退恢复时优先此法）；②tsc OOM 新形态：**vite preview + headless chromium 常驻会把可用内存压到 ~2.9G**，2400 堆也 137 三连——`agent-browser close` + 杀 preview 后 2400 堆 EXIT=0（内存敏感验证前先清浏览器进程）；③preview 5 分钟被回收后重起，localStorage 全新（语言/phone-fit/引导键全要重写，截图前先查 `library_suite_prompt_seen` + `folia_last_seen_ponder_onboarding_version`=<version> 防首启引导弹窗入镜）
- **手机适配跟进批次（2026-11-02，用户指令「修，此外这个图片为什么英文界面重复？推送，发布pre。使用技能，复渲染确认。删除旧的截图」，随 .296 发布）**
  - 背景：1080×1920 多界面 1:1 渲染集（16 屏，download/mobile-ui-preview/）审计出 P1 seam 互压（README 审计发现①）；用户追问的「英文界面重复」= 渲染脚本未设 locale，headless 默认 en-US → 应用「跟随系统」解析英文界面——真机中文系统显示中文，截图与真机不符。两件都修
  - **①P1 seam 互压（真机同样命中，纯几何不可满足）**：360 竖屏 + auto 方向 → compact 横条（home-spine，条高恒 52px）一行要放下折叠+五页签+账户+搜索/设置/队列/更多+展开，≥44px 触点下 ≈650px —— 退让链（useBravaisSeamRowFit）到底后导航段被压进零宽滚动段（页签不可达）+ flex:none 段总宽超容器溢出右缘。修复 = `libraryWallSeamDirection.ts` 新增 `resolveLibraryWallSeamHorizontalForTouch`：触屏窄视口（coarse + 宽<720，与 phone-fit/sheetPresentation 阈值族一致）上 auto/auto-reverse 兜底走竖排书脊（竖缝页签竖列、工具成格，.295 的 44px 规则两变体都覆盖）；用户显式选「横向」仍尊重（对齐「显式优先」原则）；非触屏窄窗零变化。BravaisStage 用 `(pointer:coarse)` + `(max-width:719.98px)` 两媒体查询合成 narrowTouch（该模块本就被导入，零新导入边）。探针复测：12 触点全 44×44、**0 相交**（修复前 9 处）、aria-label/axis/variant 均验
  - **②P3 aria-label 泄漏**：BottomCommandPaletteButton 引用的 `help.commandPaletteButton` 键从未存在（i18n 回退把键名原样漏进 aria-label/title）→ 复用现成 `help.openCommandPalette`，零 i18n 改动
  - **③渲染管线语言**：render 脚本 context 加 `locale: 'zh-CN'`，此后截图=真机中文界面
  - ⚠️ **环境新坑（tsc OOM 第三形态）**：`npx tsc` 会多出一个 npm exec 包装 node 进程（~226MB RSS），4G 沙箱上把 tsc 挤到 3.48GB RSS 触发 global OOM（EXIT 137 连现两次、无竞争进程）——直跑 `node --max-old-space-size=2048 node_modules/typescript/bin/tsc --noEmit --skipLibCheck` EXIT=0。此法替代 npx
  - 验证：tsc EXIT=0（直跑法）；定向 vitest 57 例（seamDirection 4 + wallLook 系 53）全绿；vite build OK；探针 0 相交；发布后全量复渲染 17 屏（zh-CN）
- **手机适配默认值批次（2026-11-01，用户指令「这是Android程序，由web端迁移过来导致UI不适合手机端，抓取相关代码绘制真实原理图再自己视觉查看并优化修复，更新cron job」，随 .295 发布）**；spec 见 /home/z/my-project/spec-phone-fit-defaults.md，原理图 download/folia-android-ui-arch.png（四层：壳→WebView→桌面本体→适配层）
  - 侦察法：vite build + agent-browser Pixel 7 视口（412×915）真实截图 6 张（phone-fit 开/关对照）+ DOM 几何测量；三问题实锤：
    - **P1** phone-fit（541 行紧凑 CSS）opt-in 默认关——手机默认安装=桌面浮卡（设置页两侧黑边/页签截断）
    - **P2** index.html viewport 缺 viewport-fit=cover——env(safe-area-inset-*) 恒 0，11 处避让规则失效
    - **P3** Seam 信息带触点 26-34px（页签/搜索/设置=手机主导航），低于 44px 标准
  - 修复（0f19ad21/5007a709/6d9a370f）：
    - P1：readStoredAndroidPhoneFitRaw 三态 + shouldDefaultAndroidPhoneFit（coarse+短边<720，对齐 sheetPresentation 阈值）+ resolveAndroidPhoneFitEnabled（存储优先/显式关不拉回）；install 生效时同步 native（修「web 开了 native 不知道」——锁转向/挖孔联动存量缺口）；isAndroidShell 调用侧给，零新导入边（tsc7 规避）
    - P2：viewport-fit=cover 一行；非挖孔设备行为不变
    - P3：`html[data-folia-phone-fit] .bravais-seam button` min 44×44 **!important**（上游 .is-short 的 min-width:34 特异性更高，必须压）；横条/竖排书脊两变体统一覆盖
  - ⚠️ 审计工具坑：①PWA Service Worker 会供旧包——浏览器验证前必须 unregister SW + caches.delete + 双刷 ②agent-browser 的 device 模拟会在重开 URL 后丢失（viewport 变 1280×577 假桌面）——测量前必核 innerWidth ③seam 有横条/竖排两变体（随墙面几何切换），CSS 覆盖须按 `.bravais-seam button` 全变体选择器
  - 验证：tsc EXIT=0 显式（首跑 137=残留 vite/chromium 挤占假阳性，清进程复跑即 0——印证「连现两次才算真」）；全量分片 13748 过+1 基线败（ytmProvider:813）+3 skip 与 .294 零差；定向 8+19 例；触点实测 12 按钮 0 低于 44px；清存储→默认生效/显式关→保持关
  - 收尾交接（20:45 后续会话）：用户指令剩余项「更新 cron job」完成——巡检 job 重建为 2918147（每 3 小时 Asia/Shanghai，载荷=.295 后基线+浏览器审计法三坑+spec/原理图路径；旧 2918066 与并行实例建的 2918141 均处于 Disabled by API 状态，已删除重建保激活）；审计残留 vite preview 进程已清。⚠️ cron job ID 勿在文档记死——用 cron 工具 list 查当前活跃 job
- **同步批次（2026-11-01 09:00+08，用户指令「我远端更新了，获取并diff，更新，完善cron job」）**：本沙箱快照落后六大发布批次（.289-.294，均为并行实例完成）——fetch 对账后 ff 到 eb4da2cb（.294 tip），npm install 重装 1344 包；补三件：
  - ①`package-lock.json` version 字段 .294 发布时漏改（停在 .293，npm install 自动纠正致工作区常脏）→ 提交 1c5f9f57
  - ②`scripts/sync-vi-to-en.cjs` 入库防丢失（meta 退役后全网只剩沙箱外部一份，重置即丢）——force-add 与 apk_cert.py 同例，并修路径解析支持 `<repo>/scripts/` 与外部两种安放位置，.294 基线 5435 键双位置 --check 通过 → 提交 3f9b3572
  - ③cron 巡检载荷刷新至 .294 后状态（旧载荷停在 .287 时代）
  - 核实：.294 workflow success、三 APK assets 各 39.8MB；main 重锚定已推（24be43a5，树停在 .291 时点、与发布线差 158 文件属正常，勿在其上开发）；main 上「Publish Limo Nightly」定时 workflow 属上游继承，success 不产 release 属正常勿惊
  - ⚠️ ff 时 blobless clone 需拉 blob，HTTP2 framing 错误重试 + `git config http.version HTTP/1.1` 后成功；被 kill 的 git 命令会残留 index.lock——先 ps 确认无进程再删

- **最新批次：弹窗「独立窗口」化 + 手势补全（2026-11-01，用户反馈「手势无效…把所有的弹窗换成适用于安卓的独立窗口」，随 v0.7.22-android.294 发布）**；设计 `docs/plans/2026-11-01-android-window-gestures-design.md`、计划 `…-window-gestures.md`
  - **背景判定**：.293 已修返回键（合成 Escape→焦点元素）与签名；用户「手势无效」的剩余缺口=①全仓库没有任何下拉关闭/横滑翻页触摸手势（.293 只把边缘滑动等同系统返回，页内横滑从未存在）②呈现仍是桌面居中定宽卡片——phone-fit 是 opt-in 设置且存储默认 false，默认安装下弹窗就是「网页里浮的一块 div」。返回键链路复核无误；老版本用户手上还是旧壳（签名断签装不上 .293）也放大了「无效」观感
  - **呈现（一处治全部 18 Sheet+11 ThemedDialog）**：`sheetPresentation({coarse,portrait,width})` 纯函数（TDD 6 边界）——触摸+竖屏+<720px='bottom'（贴底全宽、顶圆角 26px、把手、自底滑入 y:'110%'↔0，`leave:'through'`/`from` 底下不干扰），其余='card' 上游一行不动。**与 phone-fit 设置解耦：默认安装直接生效**；html 挂 `data-folia-sheet-presentation`，新 `androidSheetPresentation.css` 排 phone-fit 之后同属性 !important 覆盖
  - **下拉关闭**：Sheet 包一层只驮 y motion value 的拖拽壳（card 呈现 display:contents 布局透明）；起手限定把手+头部（`data-folia-sheet-drag`，控件上起手不拖），跟手竖直、松手 `sheetDragDecision`（TDD：fling ≥0.5px/ms 或 ≥max(120px,20%视高)=dismiss；dy≤0/closeBlocked 恒 restore）——**语义与返回键同一条：先问 onEscape（多页退页则弹回），没人吃才飞出+requestClose**；点遮罩关闭与鼠标合成事件经 isMouseDownOnOverlayRef 守卫不冲突
  - **登录窗窄版双页 pager**（用户「触摸左右滑动」的落点）：page0=平台竖列大触点（`column('column')` 自滚）、page1=登录画；**页由 chosen 派生不设状态机**（选平台→1，backOut 清掉→0）；跟手横滑 `pagerSwipeDecision`（TDD 8 例：距离 1/4 宽或 flick、轴锁纵向让位、矛盾手势不赌方向、边界橡皮、canGo 业务闸门），**page1→0 的 commit 调 onEscape(=host.backOut) 与返回键同规矩**；起手在平台行（按钮）上也能拖，真拖起来 onClickCapture 吃掉收尾 click 防误选中；桌面窄窗（无触摸无返回键）头部加「选择平台」返回钮（复用现有键）
  - **入门向导横滑**：PlaybackEntryViewPrompt（第 X 步/共 Y 步，用户「图片作为多页情景」的另一处）接 useFlickPaging（同一 pagerSwipeDecision，AnimatePresence 翻页不跟手），按钮保留
  - **自主巡检（alert 清零）**：grep 查得两处真实 `alert()`（首页端口 notify 'alert' 类通知、本地曲库自动匹配失败）——安卓 WebView 里是 Chrome 风格阻塞弹窗；改走应用内状态提示。⚠️ 首页端口若新导入 useStatusMessageStore 会引爆 tsc7（见下），改走 `getSurface().onStatusMessage`（App 层本就写同一 store，零新导入）；'alert' 合同变体保留不删（上游合并面）
  - **⚠️ 环境地雷（tsc7 原生版，双实证）**：①locale 加键——只改 zh-CN.ts 必炸（繁体派生类型层全量重算），只改 en.ts 通过；②新增导入边（createLibraryHomePort→useStatusMessageStore）同炸。沙箱 4G 无 swap、NODE_OPTIONS 无效（Go 运行时不吃）、--incremental 首跑即死。**规律：137 连现两次才算真（单次有瞬时 OOM 假阳性），加键/加导入边前先想绕法（复用现有键/走现有回调）**
  - 验证：tsc --noEmit --skipLibCheck EXIT=0；全量分片 **13743 过 + 1 存量败（ytmProvider:813 基线）+ 3 skipped**（+17 为 sheetPresentation 新例）；`git diff 2eead0b4..HEAD -- android/` 空（壳零改动，呈现/手势全在 web 层）；fork 侦察沿用 .293 结论（EasonLai96/hejunlin1755 无可借鉴）
- **上一批：实机三 bug 修复——签名稳定化 + 返回手势 + 透明开关（2026-11-01，用户报障截图两张，随 v0.7.22-android.293 发布）**；设计 `docs/plans/2026-11-01-android-signing-backgesture-design.md`、计划 `…-backgesture.md`
  - **①签名断签（无法升级，结构性缺陷非单次改错）**：CI `assembleDebug` 用 runner 现场生成的 debug keystore，一次一命 → 六版六证（.282/.286/.288/.290/.291/.292 armv8 APK v2 签名块实测指纹全不同，`scripts/apk_cert.py` 纯 Python 解析无需 JDK）→ **.281 起任何两版都无法覆盖安装**。修复=入库稳定 keystore `android/app/folia-release.p12`（PKCS12/RSA-2048/CN=folia-android，有效期 2056-10-23，指纹 A8ED29C8…FB9541）+ `android/keystore.properties`（`git add -f`，公开入库取舍见文件头注释：可安装性>防伪，fork 无商店渠道）；`build.gradle` debug buildType 也走 signingConfigs.release（+可选 storeType 透传）；workflow 加**指纹门禁**（构建后 keytool/apksigner 比对，漂移 fail fast）。⚠️ **一次性迁移公告：.292 及更早用户升级 .293 必须卸载重装（旧随机证书不可恢复），此后覆盖安装永久正常**
  - **②返回键/边缘滑动不关登录窗（殃及全部 Sheet）**：`useNativeBackButton` 合成 Escape 派发到 `window`——target=window 传播路径不含 document，而 Sheet（18 处对话框共用框）keydown 监听在 document → 返回键对所有 Sheet 失效。修复=派发到 `document.activeElement`（Sheet 打开自动聚焦面板=真实 Escape 落点）兜底 body（`nativeEscapeTarget` 纯函数 TDD 3 例）。**多页返回**：Sheet 新增 `onEscape?: () => boolean`（最顶层 sheet 才问，true=消费不关窗）；`loginHostState.backOut()`（TDD 5 例：未选/未开/动画中=false，已选=结束一轮停登录清回列表=true）；接线 LoginHost→LoginScreen→LoginWindow→Sheet——二维码页返回→平台列表→再返回→关窗。边缘滑动=系统返回=同路径一并修复
  - **③播放页透明开关删除（Android 死开关）**：透明窗口是 Electron 能力（OBS/抠像），Android WebView 合成器不透明。IntegrationPage 透明行 `isElectron` 门控 + 命令面板 `settings-toggle-transparent` 加 `platform: ['electron']`（availability.ts 现成机制）；底层链路保留降合并冲突
  - **fork 侦察**：EasonLai96（Capacitor 移植，MainActivity 无返回键定制）、hejunlin1755（pc-for-android，CI 同样裸 assembleDebug=同样断签）——两问题无现成借鉴，本仓首发修复；上游 scratchpad 批次（b54f3681 等）留下一轮迁移
  - ⚠️ 显示层教训补充：本轮工具输出会吞 `[h` 序列（`[host]` 显示成 `ost`、`a[href]` 显示成 `aref]`），两处疑似 typo 均为伪影——**od -c 字节级验证才可信**（与上批 ANSI 教训同源）
  - 验证：tsc --noEmit --skipLibCheck EXIT=0；定向测试 nativeBackButton 8 例 + loginHostState 23 例 + command-palette 313 例绿；全量分片 13726 过 + 1 存量败（ytmProvider:813 基线）+ 3 skipped（+8 新例）。**CI 四跑终绿（19:48 UTC published，三 APK 各 39.8MB）**：门禁三轮误拦的根因是 apk_cert.py 首版把 v2 长度前缀当 TLV 自含解析产出垃圾指纹（改纯标准库正确解析后与 keytool/openssl 三方一致）；**签名闭环实测：.293 armv8 证书=A8ED29C87807D2535B…（=入库 keystore，openssl 复核 CN=folia-android）≠ .292 真实证书 53F9FF98…（随机 runner debug 键，修正后重测六版真实指纹各不相同，「每版一证」结论成立）**；release body 已写卸载重装公告；gradle 侧 signingReport 实证 debug→Config release→folia-release.p12（诊断步保留在 workflow 里作常态审计）
- **上一批：Folium 1.8 跟进——町景性能 + 歌词画布渲染质量 + mod API（2026-10-31 23:00+08，用户指令「查看它干什么的再合理迁移（注意android背景）」放行，随 v0.7.22-android.292 发布）**；设计 `docs/plans/2026-10-31-folium-1-8-render-quality-design.md`（三提交拆解/交互分析）、计划 `…-render-quality.md`（6 任务）
  - 上游范围（v0.7.25 之上 main 合入 3 有效提交）：3b4f01a7 Folium 1.8（111 文件 +3470/-788）+ a390a45b（导出 1×/心象默认）+ c56bf8ec（雾笺排版画布 #963）；fa9522d4/d695db52 代码地图 chore 跳过（惯例）
  - 逐笔 cherry-pick -x 落地：
    - ebad05ab ← 3b4f01a7：町景切换不卡主线程（engine/programWarmup 按真实渲染目标预编 + KHR_parallel_shader_compile 后台编 + 分段建场景；降级顺序改：先景深/超采样/MSAA 再倒影/辉光/分辨率/后期抗锯齿，阴影最后；degradeStatus 面板显示降了几档）+ 歌词画布全局渲染质量挡位 lyric_render_quality（分辨率 0.5×-2× + 抗锯齿 auto/on/off，10 样式「渲染」组）+ Folium mod API 7 文件随树全收（Android 无 Electron，零行为）
    - 3dba3e93 ← a390a45b：视频导出固定 1×（pinMachiQualityForExport + renderPinned）+ 心象「默认」不重置面板没有的项；冲突语义合并：我们的 Android 帽（effectiveTuning）与上游 pin 共存，**pin 后再过一遍 Android 帽**（导出状态不放宽）
    - 86ed6264 ← c56bf8ec：雾笺 resize 改量 clientWidth/Height（不受 transform 影响，修预览笔画粗细 #963）；与 .291 cold-start 的 hostSize 拆分语义合并（hostSize 同改 clientWidth，预设画布与度量一致）
  - **旧 #929 体系退役（d9796d6a 简版 → 上游完整版）**：useLyricSettingsStore 删 lyricRenderQuality/lyricAntialias 字段与 handler（契约快照同步）；LyricsPage 旧「歌词渲染」组删除（新挡位在「性能与动效」GraphicsPage）；旧键 i18n（lyricRenderQuality/lyricAntialias 旧文案等）四语言清除；lattice（bravais 墙歌词，不在上游 10 样式清单）桥接新全局挡位（latticeLyricResolution 加 scale 参数走 resolveLyricPixelRatio）；**存档迁移（ecca8345，TDD 4 例）**：readStoredLyricRenderQuality 首读时 lyrics_antialias=true → {scale:1, antialias:on}、false/未设 → 默认，写新键删旧键
  - **钳制层适配（04dee608+3d63086b，TDD 12 例）**：'global' 字段先按全局挡位 resolve（上游 settle 语义：global.scale 直接数值化、on/auto→SMAA、off→off）再走低档帽；全局倍数 1.5/2 也进帽比较；PRESETS 类型放宽后 LOW.renderScale 收窄为 LOW_RENDER_SCALE；帽下引用稳定语义保留；调用方传 useGlobalLyricRenderQuality（含导出钉住值）
  - ⚠️ **环境教训**：①工具输出管道会吞 `[m`（ANSI reset 序列）——`[machiTuning]` 显示成 `achiTuning]`，曾误判为 typo（od -c 字节级验证才可信）②tsc 大 heap（2560/3072）在 4G 沙箱会被 OOM 静默 kill（EXIT 137 无输出），**必须 2400 堆 + 输出到文件 + 显式 exit code**；.290/.291 的「tsc 0 错」当时可能未真跑完，本次全量显式验证 EXIT=0
  - 验证：tsc --noEmit --skipLibCheck **EXIT=0 显式验证**（2400 堆）；unit 全量 **13718 过 + 1 存量失败**（ytmProvider:813，.290 起基线同败）+ 3 skipped（总数 13644→13722，+78 为 Folium 1.8 新测试）；androidVisualizerPerfCap 12 例 + 迁移 4 例绿；pin 快照 43 例（上游新 pin 并入）；`git diff 3450fff9..HEAD -- android/` 空（壳零改动）；四语言 lyricRenderScale/lyricAntialias 齐全、旧键清零
- **仓库维护批次：main 重锚定 + 分支清理（2026-10-31 20:30+08，用户指令「清理分支，更新仓库」）✅ 已推**：
  - **沙箱重置恢复**：folia-android/ 与凭证全部丢失；`git clone --filter=blob:none` 恢复（tip 与 .291 tag 一致 1a1fd2b1，零丢失）；upstream 重挂；MERGE-STATE 本文件即接力源
  - **origin 远端盘点**：仅 3 heads（android-0.7.22 发布线 / main / meta）+ 11 tags（.281-.291）全部有效，**无垃圾分支可删**
  - **main 重锚定 ✅（本地完成待推）**：`main-relaunch` = android-0.7.22 + 两个 `-s ours` 声明式合并（ad82d546 吸纳 origin/main 207 独有提交、e1a598f2 吸纳 upstream/main，树与发布线 diff=0）。背景：origin/main 与 upstream/main 分叉 207/587，真 merge 冲突 214 文件不可行；main 线工作已全量回流发布线（QQ 批次对账 0 缺口），声明式吸纳=历史可达性恢复（fork 页 behind 提示消除）+ 零丢失。**待 push：`git push origin main-relaunch:main`**
  - **⚠️ Folium 1.8 新批次侦察（待用户拍板跟进）**：.291 发布后 20:09+08 上游合入 3 个有效提交（v0.7.25 之上）：
    - `3b4f01a7` **Folium 1.8 大提交：111 文件 +3470/-788**——①町景切换不卡主线程（programWarmup 按真实渲染目标预编 + KHR_parallel_shader_compile 后台编 + 分段建场景，冷启动主线程 1.8s→50-85ms；降级顺序改：先景深/超采样/MSAA 再倒影/辉光/分辨率/后期抗锯齿，阴影最后；稳态开销削减）②歌词画布全局渲染质量挡位 `lyric_render_quality`（分辨率 0.5×-2× + 抗锯齿自动/开/关，10 样式各加「渲染」组可独立覆盖，町景两项加「跟随全局」，雾笺分辨率滑块并入共用设置）③Folium mod API（getRenderQuality/setRenderQuality + electron/modSystem + mods/folium.d.ts + docs——**桌面 mod 系统专属，Android 无 Electron**）
    - `a390a45b` fix：视频导出固定 1× 画；心象「默认」不重置面板没有的项（11 文件）
    - `c56bf8ec` fix：雾笺按排版尺寸量画布，预览笔画粗细生效（1 文件）
    - 适配要点：③建议随树全收保持零分叉（Android 构建不含 electron 代码）；①的 machi 降级顺序改动**与我们 androidVisualizerPerfCap 钳制层交互需重点测试**（钳制在帽下让位、新降级顺序是否穿透）；②与我们旧布尔键 `lyrics_antialias`（useLyricSettingsStore，#929 先行实现）存在键位关系，需设计旧值→新挡位迁移
- **上一批：雾笺窗外场景跟进——上游 scenery-toggles + cold-start（2026-10-31，用户指令「大版本跟进/比对差距/不适合则等价实现/发布」放行，随 v0.7.22-android.291 发布）**；计划 `docs/plans/2026-10-31-nebbia-scenery-toggles-cold-start.md`
  - 上游状态：`upstream/main` HEAD 仍 = v0.7.25（20c3ecd0，limo tag 对齐）；本批 5 提交来自两条**未合并**分支（PR 状态匿名 API 限流查不到）：`feat/nebbia-scenery-toggles` 4 提交 + `perf/nebbia-cold-start-no-gpu-wait` 1 提交
  - 逐笔 cherry-pick -x 全部干净/语义合并 ✅：
    - bace7cdc ← 69f9fd16（窗外各样单独开关：天气/楼群/路灯等逐项可关，雨可斜/竖/无；新键 nebbiaScenery 4 例）
    - 541a632f ← 37bcf576（窗外可换共用背景 `behind: 'backdrop'` + 播放页透明透出桌面；新文件 nebbiaBehind.ts：nebbiaSeesThrough/nebbiaBackgroundConfig；seeThrough 时画布带 alpha、运行时整建）
    - 3845ddbc ← 5a382dd7（透明时雾色跟主题日夜、水珠折射街景）
    - e81ab053 ← 6c9e40d7（节拍钟 fix：只算画出来的背景；smartBeat 45 例）
    - cf316e34 ← 15152f2c（冷启动：建上下文前按宿主尺寸预设画布 fitNebbiaCanvas + 5760² 面积帽；无 KHR_parallel_shader_compile 时 fenceSync 栅栏替代忙等）
  - **唯一冲突**：nebbiaPrograms.ts——cold-start 分支基于旧 main（五程序时代），本线 v0.7.25 final-state 已有 noise 第六程序；语义合并=六程序 list + fence 栅栏逻辑共存（nebbiaPrograms.test.ts 8 例绿验证）
  - **Android 适配判定**：5 提交全部纯 web 层，直接适用（判定矩阵见计划文档 §0）；「播放页透明透出桌面」路径依赖宿主窗口透明（Electron/OBS），Android WebView 不透明为存量基线、该路径行为不变不报错，**等价实现结论=不改壳**（backdrop 核心体验 Android 全量可用；WebView 真透明透壁纸超范围，不做承诺）
  - 验证：tsc 0 错；unit 全量 **13640 过 + 1 存量失败**（ytmProvider:813 no-browser 用例，.290 基线同败非本批）+ 3 skipped；pin 快照 43 例（上游新增 pin 自动并入）；androidVisualizerPerfCap 7 例绿（machi 钳制不回归）；nebbia 全系测试（scenery 5 + programs 8 + smartBeat 45）绿；`git diff 672f7fe4..HEAD -- android/` 空（壳零改动）；四语言 backdrop 键齐全
  - **观察项**：①上游这两条分支合并/rebase 后需 `git cherry` 对账增量（尤其 cold-start 若 rebase 到六程序 main，比对语义合并差异）；②scenery-toggles 若新增提交继续跟进
- **上一批：上游 v0.7.24/25 全量迁移 + QQ 批次补齐 + 「快捷键显示」（2026-10-31，用户八问拍板后放行，随 v0.7.22-android.290 发布）**；设计 `docs/plans/2026-10-31-upstream-0.7.24-25-qq-shortcut-hints-design.md`（§0 八决策）、计划 `…-hints.md`（14 任务）
  - **上游 v0.7.24 (adf86215) + v0.7.25 (20c3ecd0) 全量迁移 ✅**（71 非合并提交，v0.7.23 为 base）：
    - 雾笺 nebbia（WebGL2 雨夜窗景 43 文件）+ 町景 machi（three.js 雨夜街景 71 文件）final-state checkout（c224f24b）；文件级对账：与 upstream/main 仅差 machi Android 钳制接线 7 行（本线专属，非漏迁）；`dev/nebbia/nebbiaStrokesPlugin.mjs` 笔顺构建插件（commit 钉死 + 逐文件 sha256 + 失败软降级 + `FOLIA_NEBBIA_STROKES=off` 逃生门）+ `licenses/nebbia-strokes/`
    - fix 批 cherry-pick -x（1fe89c65）：lucide Path2D、主题默认回套、汽水试听提示×2、AudioContext 输出设备、Spotify 官方限制提示、AI i18n 中性化、remote 队列展开动画、bravais 信息条自动反向；intro「新功能」卡片 0.7.25 Rainy SP1（dad8c34c）；i18n 四语言全键（fca7aacc）
    - 跳过（纯桌面/不适用）：d12f54da、ad5763cd（chore(dev) 代码地图 [skip ci]）、c81dc148（chore(skills) 上游协作流程文档）
  - **QQ 批次缺口补齐 ✅**（4f945888 收尾）：origin/main 970ef5be..d1d11bf7 共 38 提交逐笔判定补齐（扫码登录通道、点赞/unlike、订阅、g_tk、QIMEI、KRC、QQ 渲染优化与 .289 已迁 2 笔汇合），`git cherry` 对账 **0 缺口**
  - **Android 性能兜底 ✅**（e278adfc，决策 #3）：`src/utils/androidVisualizerPerfCap.ts`——Android WebView 上町景生效值钳低档（抗锯齿/阴影/倒影/bloom 关、renderScale 不高于低档），存储值不动、帽下同引用（免运行时重建）、adaptive 保留让上游帧时降档在帽下工作；桌面零改动；雾笺不钳（上游已 1/8 雾层 + 双程序后台编译；WebGL2 缺失时组件级退回只显示当前句）；7 例直测
  - **「快捷键显示」✅**（决策 #4-#7：默认关、键鼠任一接入自动开、全拔自动关、HelpPage 查阅页除外）：
    - store + resolver（db8162b4）：`shortcut_hints_mode` 三态 auto（默认）/on/off，`resolveShortcutHintsVisible` 纯真值表；store 契约快照更新
    - useHidConnection（75a239f3）：Android 先查 `getConnectedHidDevices` 后订 `onHidDevicesChanged`（防丢事件）；桌面 matchMedia 兜底；Electron 恒接入 → 桌面行为零回归；8 例
    - 原生监听（a81e3004，决策 #5）：FoliaNativePlugin `registerInputDeviceListener` + SOURCE_KEYBOARD/MOUSE 位测（isFullKeyboard 归键盘）+ isVirtual 跳过 + `getConnectedHidDevices` PluginMethod；与既有 41 个 PluginMethod 共存
    - 三徽章受控（245ef495）：WallToolsRows / LatticeFocusButton / BravaisStageChrome 三处 kbd 徽章全部走生效值，Playwright 组件测试锁定
    - 教程分镜运行时切换（73664e4a）：`useOnboardingTouch()` 键鼠/触屏分镜按接入即时切换（含 keycap），触屏常量保持具名（T5 坑）
    - 三态设置行（f96424fa）：InteractionPage「快捷键显示」自动（跟随键鼠）/始终显示/始终隐藏，仅 Android 壳渲染该组；四语言键（vi 人工翻译）
  - 验证：tsc 0 错（--skipLibCheck，同基线法）；unit 全量 **13631 过 + 1 存量失败**（ytmProvider no-browser 描述用例，基线 .289 同败非本批）+ 3 skipped；components 定向 **156 过**（wallToolsIsland 20、bravaisHome 25、ponder 三件 40、settings 两件 18、pixiVisualizerResize 10、lattice 27、bravaisChrome 14——**bravaisChrome:137 存量失败本次也过**）+ lattice 277/564/594 存量失败与基线一致；e2e 定向 interactionSettingsSection 6 + ponder 6 + nomandSettings 全过，helpCommunity 5 存量失败（基线 .289 同败）；`build:capacitor` 产物齐全（nebbia/machi 入包、`nebbia-strokes.json` + licenses 打包）；⚠️ 沙箱 2 核 swiftshader 组件测试 ~12s/例，accountBehavior 等重型 spec 基线同慢（15.9m 跑不完 43 例，环境限制非回归）；Java 编译验收交 CI（沙箱无 javac）；后台进程会被沙箱会话回收，长测必须前台分批跑
- **v0.7.22-android.289（2026-10-31）**：Android 7 闪退修复（90072e92）+ 实时日志落盘（d3bc59e3）；tsc 0 错、定向 vitest 304 例全过、build:capacitor 237 项
- **上游 v0.7.23（120 提交，B6-1..B6-6）：✅ 全部合入**（`git cherry android-0.7.22 v0.7.23` 零缺口，两个实例各自独立验证过），随 v0.7.22-android.282/.283/.284 发布
- **T1-T6 修复任务**：T1 启动闪斜体 ✅、T2 触屏按钮裁剪 ✅、T3 后台节流 ✅（真机耗电验证仍待，需实机）、T4 搜索页X误触灯泡 ✅、**T5 教程触屏分镜 ✅（随 .285 发布）**、T6 杂项视为关闭
- **issue 务实修复批（用户指令「去理想化修复issue」放行，随 .286 发布）**：
  - **#869 ✅**（162c279c）流式音源 duration=Infinity 时用元数据时长兑底上报 MediaSession 进度
  - **#889 ✅**（500d99bb）平台判死曲目（taken-down/no-audio/audio-unplayable/not-public）不倒数直接切下一首，即时跳过上限 20；新选项 `skipLoadingStatusToast` 让失败提示短暂可见
  - **#843 ✅**（d91f34c6）bravais 拖动相机改 rAF 目标插值（tau=8ms，收敛 snap 半设备像素），renderFrame 从帧状态新增的 renderCenter 出变换；spec 见 /home/z/my-project/spec-issue-fixes-2026-10-29.md
- **最新发布：v0.7.22-android.289（2026-10-31，用户指令「触发workflow发布新版本，自行下载所需工具和依赖辅助审查」放行）**：
  - **Android 7 闪退修复 ✅**（90072e92，自 main 7ab60536 移植）：FoliaPlaybackService 通知构建用 API 26 双参构造器 Notification.Builder(Context, channelId)，而第一次构建通知恰在「打开歌曲→获取歌曲链接」时，Android 7（API 24/25）上抛 NoSuchMethodError 闪退；按 SDK_INT 分支构造器，setter 链两分支共用（全自 API 21 起存在）
  - **实时日志落盘 ✅**（d3bc59e3，自 main 578efcd5 移植，对齐桌面 debug 模块）：SAF 选文件夹（ACTION_OPEN_DOCUMENT_TREE 持久授权），每次启动新建 folia-log-<时间戳>.txt（保留最近 8 个、只删自家前缀），console 行 500ms 批量即写即刷，崩溃前最后一行落盘；开卡回放内存缓冲；授权失效/写失败可见化。consoleLogBuffer 增 addConsoleLogSink 双 sink 并存
  - **审查适配（本线移植时的差异）**：设置卡按本线 pages 结构用 kit Group/Row 写进 DeveloperPage（main 线的 DeveloperSettingsSubview 本线零引用，已删）；FoliaNativePlugin.java 与上游 Spotify 登录段共存（41 个 PluginMethod 全保留）；vi 文案人工翻译非英文占位
  - **⚠️ main 线与发布线的 QQ 批次缺口（下批需用户拍板）**：main 上的 QQ/NetEase/KuGou 修复系列（970ef5be..d1d11bf7，约 25 提交：QQ 扫码登录/点赞/订阅/vkey/射频，0.7.20 基线）从未进发布线；本次按指令只移植本会话两笔。若要移植需跨 0.7.20→0.7.23 基线，冲突面集中在 qqTransport/nativeBridge/i18n
  - 验证：tsc 0 错；定向 vitest 304 例全过（consoleLogBuffer/i18n×4/settings 全套 23 文件/nativeBridge×2）；build:capacitor 产物 237 项正常；⚠️ 本环境 4G 内存，tsc 会被残留 Gradle 守护进程挤 OOM（先 `pkill -f GradleDaemon` 再跑，NODE_OPTIONS=--max-old-space-size=3072）
- **v0.7.22-android.288**（三件套批次：#929/#866/轻量模式第一阶段；分片全量回归 3 片全过；workflow run 40981761203 success，三格式 APK assets 齐全，armv7/armv8/universal 各 37.6MB）
- fork 仓库 0 issue（开+关均 0）；上游 34 个开放 issue，已筛出 Android 相关角度（见下）
- **巡检（2026-10-29 17:05 +08，沙箱重置后恢复）**：origin tip 与 tag .286 一致（1695a272）、workflow run#7 completed/success（APK 已发）、上游 **v0.7.24 未发 tag**（最新 v0.7.23，main tip f96c65b2）——无合并动作；发现 android-0.7.22 分支上的 MERGE-STATE.md 漏推 .286 版（已补同步，docs 提交 6db9534d，此后 tip 可领先 tag 一个文档提交属正常）；凭证/仓库/scripts 均已重建（blobless clone）
- **APK 多格式发布（用户指令「apk少了几个格式armv7 universal armv8」，随 .287 发布）**：`android/app/build.gradle` 加 `splits.abi`（armeabi-v7a + arm64-v8a + universalApk），workflow Rename 步骤改为三产物（`folia-<v>-armv7/-armv8/-universal.apk`）；spec 见 /home/z/my-project/spec-apk-abi-splits.md；提交 1f696ba3。**纯构建配置改动跳过 tsc/vitest，以 CI 构建结果验收**
- **fork 生态侦察（2026-10-29，用户指令「查看forks找找亮点」）**：本仓库 0 fork；folia-major 50+ forks 无实质领先（最多 ayegeer105-del +7 全是 README 更新；chenlibiao2004-tech +3 是 vercel API 代理）。第三方 Android 移植亮点：
  - **huleixin/folia-rear-lyrics（22⭐）**：小米 17 Pro 背屏歌词（Shizuku 授权，保留歌词舞台样式铺满背屏）；**轻量 mobile 界面**（虚拟列表+独立底部播放条，Android 默认启用可切回）；发布规范好（APK SHA-256、源码快照 zip、AGPL 署名；版本 `0.7.20-android.194-rear.r245` 叠 fork 后缀）。**mobile 轻量界面思路值得借鉴**（低端 Android 机性能）
  - **Sakurakilove/folia-major-android-apk**：bravais 滑动裁剪图块呈现顺序修正（避免保留封面节点反复 detach/reinsert，与 #843 相邻）；暂时关闭 Kyant 原生折射层换网页实时模糊（WebView 性能务实取舍）；REPAIR_STATUS/WORKLOG 文档纪律；只发 arm64 单包
  - **yezitotempeace/folia-android**：双安装包（带/不带模组商店）功能变体；**davaded/folia-android**：x86_64 车机 GeckoView 壳；**结论：生态无任何项目做 armv7/armv8/universal 三件套，.287 做即首个**
- **三件套批次（用户指令「查看，开始#866/929和轻量工作」放行，随 .288 发布）**：
  - **#929 ✅**（d9796d6a）歌词画布渲染倍率/MSAA 一等设置：`src/utils/lyricRenderQuality.ts` resolver（auto/1/2/3，auto 保留各风格旧行为）；lyricRenderQuality+lyricAntialias 挂 useLyricSettingsStore；lattice/hanabi/lumiere/fume 四处接入（fume snapshotScale 钳 2）；glyphs 图集上限改 `4096*resolution`；hanabi antialias 读设置；rebuildKey 重建（lattice 走 resize 更轻）；LyricsPage 新「歌词渲染」组
  - **#866 ✅**（95f344e4）M3U 歌单跟源 + 启动自动重扫：LocalPlaylist.sourcePath；upsertLocalPlaylistFromFile（sourcePath 精确或同名兜底匹配→更新不新建，名字/收藏保留；normalizePlaylist 透传 sourcePath）；autoRescanOnStartup（默认关）+ useLocalLibraryStartupRescan 启动 4s 重扫（Android=MediaStore 扫描，是移动端唯一自动重扫入口——FileSystemObserver 在 Android 不可用）；StoragePage 全平台「启动时重扫」组
  - **轻量模式第一阶段 ✅**（470693f2）：useAndroidLayoutSettingsStore.liteModeEnabled（Android 壳默认开）；VisualizerTempera 生效 tuning 强制 postProcessEnabled=false（只改生效值不动存储）；GeneralPage Android 组开关。v2 扩展点：列表虚拟化、更多特效降级
  - **测试债**（dae8be6f + 2c6be26a）：.286 #889 漏更新 4 个 countdown 期望测试，已还清；queueReplaceRaces 两例改用 sign-in-needed 保留 countdown 窗口测替换竞态
  - **契约修复**（0ebb5cff/95bdaf4b）：storeContract 靠模块级 XXX_KEY 常量声明抓 key——新 store key 必须用常量模式，勿用裸字面量（lyrics_antialias 教训）
- **⚠️ 双实例接力（2026-10-30 00:00-00:45）**：本批三功能由会话 A（00:09-00:24）完成提交+定向验证；会话 B 接手跑分片回归、还 queueReplaceRaces 债、发布 .288；会话 A 随后补 storeContract 契约修复（95bdaf4b）。两实例在同一沙箱文件系统交错操作，靠 git log/reflog 理清，无冲突
- **⚠️ 环境新坑（2026-10-29）**：①全仓库 4478 文件 chmod 644→755 的 mode 噪音：`npm version` 必触发，且**环境自身也会周期性触发**（00:00 巡检实测，未跑 npm 仍出现）——改版本号一律 node 手工改 package.json+package-lock.json；遇到 status 大片 M 先看 diff 是否纯 mode（0 insertions），是就 `git restore .` 清理；②`~/.git-credentials` 与 global `credential.helper` 会被环境定期清掉（本日两次）——重建法在速查区；③`git restore .` 前必须先 stage 真实改动（本次误伤 build.gradle/workflow 编辑重做一遍）

## ⚠️ 并行实例协议（2026-10-29 15:00 触发实测）

同一次 cron 触发出现过**两个 agent 实例并行**操作同一仓库（一个完成 T5 验证+发布 .285，另一个建 meta 分支+验证 cherry）。接力的会话**动手前必须**：

1. `git fetch origin && git log origin/android-0.7.22 --oneline -3` + `git ls-remote --tags origin` —— 看 tip 和最新 tag，别重复发布、别基于旧 tip
2. `ps aux | grep -E "vitest|tsc|npm exec"` —— 有残留进程先判断是谁的（reflog 看时间线），**不要贸然 reset --hard**；必要时先备份工作树文件
3. `git reflog -10 --date=format:'%H:%M'` —— 理清 HEAD 移动史，识别另一实例的动作
4. 推送/打 tag 遇到已存在就适配（读 origin 状态），不要 force

### 实例互踩实例（教训）

- 甲实例 `git checkout --orphan meta` 失败（乙实例已建）后，`&&` 链被 `| head` 吞掉退出码继续跑，`git rm -rf --cached . + commit` 把 android-0.7.22 本地 tip 污染成 2 文件树 → 靠 reflog 定位、`reset --hard <好提交>` 修复（origin 未受影响）。**教训：链式命令里别用管道吞关键命令的退出码；破坏性命令前先 `git branch --show-current`。**

## 下一批从这里开始

1. v0.7.23 已全部收尾；上游 main 已领先 v0.7.23（v0.7.24 开发中，截至 2026-10-29 领先 7 个非 merge 提交：remote 队列展开 #926、底部字幕布局 #924、login 测量修复 #914、fix(dev)、RPM build-id 等），**不要提前去合**，等上游出 v0.7.24 tag 或用户指示
2. 待办：T3 真机耗电验证（需要实机，沙箱做不了）
3. ~~#866 / #929 / 轻量模式第一阶段~~ ✅ 已随 .288 完成（见上「三件套批次」）；~~tip 遗留两个契约修复提交~~ ✅ 已随 .289 发布；轻量模式 v2 候选扩展：列表虚拟化、更多特效降级
- **巡检（2026-10-31 11:15 +08）**：.289 已发（5ccf86af 发布提交 + tag，main 线 7ab60536/578efcd5 两笔移植）；上游 v0.7.24 仍未发 tag——无合并动作；main 线 QQ 批次缺口记录在 .289 条目内待用户拍板

## T5 实现备忘（2026-10-29 完成）

- 分流开关：`src/components/ponder/targets/basics/ponderOnboardingShared.ts` 的 `ONBOARDING_TOUCH`（模块级求值一次，`FINE_POINTER_QUERY` 取反；node 测试环境无 window → 桌面分支）
- 触屏分镜：`helpPage.target.ts`（overview/commandPalette）+ `ponderBasics.target.ts`（insidePonder/wholePage），各自导出 `TOUCH_SCENE_STEPS`
- 原则：触屏没有悬停/键盘，keypress 一律换成灯泡（touchBulb 锚点）或左下角命令面板按钮的演示；不硬凑等价物
- 新增 i18n 键 ×4（`overviewCtrlGTouch`/`overviewCommandPaletteTouch`/`hereTouch`/`wholePageTouch`，四个语言文件都有）
- 测试：`ponderRegistry.test.ts` 新增「触屏分镜与桌面分镜过同一道防线」（锚点/id/结果层/时间线编译 + 触屏禁止 keypress）
- ⚠️ 已踩坑：`TOUCH_SCENE_STEPS` 不能引用 `scene.steps`（模块求值时已被三元定格成桌面分支），必须用具名触屏常量

## sync-vi-to-en.cjs（重建版要点，两实例收敛为同一实现）

- 行级 tokenizer：顺序 = 注释/空行 → export → 闭行（容忍 `} as const;`/`},`/`]`）→ 对象开 → 数组开 → **数组项（先于叶子）** → 叶子（最宽松放最后）
- 旧版「括号未闭合(剩 1 层)」的死因：闭行没容忍 `} as const;`、数组项被宽松叶子规则吞掉
- 数组项按数组内位置编号（`#N`），不能用行号（两文件行号天然错位）
- 用法：无参=对齐+写回；`--check`=只校验（漂移退出 1）。en 有 vi 无的键 → en 原文占位插入 vi，待人工翻译
- 副不变式：in.ts ↔ zh-CN.ts ↔ en.ts 键同步（missingTranslation.test.ts 把关）
- 本文件所在发布线与 `/home/z/my-project/scripts/` 各存一份（双位置自适应，入库版为准）

## 全量回归的可靠跑法（沙箱实测结论）

- 沙箱 3.9G RAM / cgroup 4G；tsc 峰值 2.7G+ 会 OOM（dmesg 可查 `Killed process ... tsc`）——跑 tsc 前先杀别的 node 大进程
- **nohup 后台跑长任务会被沙箱驱动在 ~5 分钟回收**（实测两例），且 stdout 接管道结果丢失
- **可靠做法：`--shard` 分片前台跑**，每片 ~3.5 分钟（在单命令 10 分钟时限内）：
  `npx vitest run -c vitest.config.ts --silent=true --exclude "test/unit/ytm/**" --exclude "test/unit/discordPresence.test.ts" --shard=1/3`（再 2/3、3/3）
- 全量基线：1052 文件 / 13018+ 用例；--silent 必须 =true 否则吃掉路径参数

## 会话恢复速查

```bash
# 凭证（丢了才执行；PAT 已持久化在 /home/z/my-project/.gh-credentials，重发后自动恢复；巡检 cron job 用 cron 工具 list 查询，勿记死 ID）
printf 'https://SkyRoc-114:<PAT>@github.com\n' > /home/z/my-project/.gh-credentials
chmod 600 /home/z/my-project/.gh-credentials && cp /home/z/my-project/.gh-credentials ~/.git-credentials
git config --global credential.helper store && git config --global http.version HTTP/1.1

# 克隆（网络抖动时用 HTTP/1.1 + blobless；GnuTLS recv error / HTTP2 framing 就重试）
git clone --filter=blob:none --single-branch --branch android-0.7.22 https://github.com/SkyRoc-114/folia-android.git /home/z/my-project/folia-android
cd /home/z/my-project/folia-android
git remote add upstream https://github.com/chthollyphile/folia-major.git
git fetch --filter=blob:none upstream

# MERGE-STATE.md 与 scripts/ 已直接跟踪在 android-0.7.22 分支（meta 已退役）；
# sync-vi-to-en.cjs 双位置自适应：<repo>/scripts/ 或 /home/z/my-project/scripts/ 均可跑

# 依赖（必须官方源 + ignore-scripts）
npm install --registry=https://registry.npmjs.org --ignore-scripts --no-audit --no-fund

# 每批验收
npx tsc --noEmit && npx vitest run -c vitest.config.ts --silent=true --exclude "test/unit/ytm/**" --exclude "test/unit/discordPresence.test.ts"
# 改了 en.ts / zh-CN.ts 后：
node /home/z/my-project/scripts/sync-vi-to-en.cjs
```

## fork issue 角度（2026-10-29 从上游 34 个开放 issue 筛出；fork 自身 0 issue）

**Android 直接相关（建议优先）：**
- **#843** bravais 墙 180Hz 拖拽节奏抖动 → rAF 目标插值 + 像素吸附：触屏拖拽平滑度，Android 帧率/DPR 受限时更明显
- **#929** 歌词画布渲染倍率/MSAA 成一等设置：Android 壳刻意关 MSAA、限帧率省电，这个设置应带 Android 默认值
- **#866** M3U 跟源文件更新 / 本地文件夹自动重扫：Android 的 SAF/存储权限与桌面 inotify 不同，合并时要设计 Android 分支
- **#889** 平台判放不了的曲目直接接下一首：移动网络/后台场景更痛
- **#869** 在线音源进度上报系统媒体控制：SMTC 是 Windows 概念，Android 对应 MediaSession —— 检查 fork 的 MediaSession 是否同步在线音源进度，可作为 fork 自己的修复项

**合并时顺带（上游先做）：**
- **#834** Bravais 墙双击封面直接播放（触屏友好）、**#848** 海报歌词 ruby 注音、**#918** 歌手页无专辑单曲、**#867** 心动模式、**#840** 在线多类型搜索、**#919** 电视端（大屏/遥控器 UI，Android 系可借力）

**跟踪即可：**
- QR 登录失败系列（#925/#908/#883/#882/#873/#861/#826/#851，多为 needs-info；fork 已有自己的登录错误文案修复 7ae2ff05）
- #928 声卡切换只切 audio（HiFi Web 引擎路线留意）、#870 遥控窗口美化（桌面向）、#850 模组只读接口、#901 酷狗每日推荐

## 批次收尾清单（每批照抄）

1. cherry-pick / 改动 → 冲突按「fork 的 nativeBridge/android 增量优先，上游语义不丢」解
2. `node /home/z/my-project/scripts/sync-vi-to-en.cjs`（动了 en.ts / zh-CN.ts 时）
3. `NPM_CONFIG_REGISTRY=https://registry.npmjs.org/ npm install --ignore-scripts --no-audit --no-fund`（动了依赖时；沙箱默认 npmmirror 环境变量会盖项目 .npmrc 致 EALLOWREMOTE，见 .301 批次）
4. `npx tsc --noEmit` 0 错 + 定向 vitest；大批次全量回归用 `--shard` 分片前台跑（当前基线：~13757 过 + 1 存量败 ytmProvider:813 + 3 skip；以 PROGRESS.json baseline 为准）
5. 更新本文件（+scripts/ 若有新增）→ push `android-0.7.22`（meta 已退役不再推）
6. 推 tag 前先查上次 workflow：`curl -H "Authorization: Bearer $PAT" .../actions/runs?per_page=2`，确认 success 再 `git tag v0.7.22-android.NNN && git push origin <tag>`；发布提交必须同改 package.json **与 package-lock.json 两处 version**（.294/.300 均曾漏改 lock）
7. **轮次收尾（2026-11-04 进度变量化）**：`python3 scripts/update-progress.py round --type batch --result "<一句话>"` + `set fork.latest_tag/next_batch_number` + `history <tag> <sha> "<summary>"`（pending 有动则 pending-add/pending-done）→ PROGRESS.json 与本批一并提交 push
8. 勿用 android-actions/setup-android@v3（runner 预装 sdkmanager 冲突）
